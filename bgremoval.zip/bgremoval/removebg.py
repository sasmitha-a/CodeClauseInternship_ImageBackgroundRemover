# Importing Required Modules 
from rembg import remove 
from PIL import Image 

# Store path of the input image 
input_path = r'C:\bgremoval\dog.jpg' 

# Store path of the output image 
output_path = r'C:\bgremoval\dog_output.png'  # Change the output file name or path

# Processing the image 
input_image = Image.open(input_path) 

# Removing the background from the given Image 
output_image = remove(input_image) 

# Saving the output image in the given path 
output_image.save(output_path) 
